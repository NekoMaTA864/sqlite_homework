const express = require('express');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const session = require('express-session');

const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'views')));

// Set up session
app.use(session({
  secret: 'your_secret_key',
  resave: false,
  saveUninitialized: true,
}));

// SQLite database setup
const dbPath = path.join(__dirname, 'restaurant.db');
const db = new sqlite3.Database(dbPath);

// Routes
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

app.get('/register', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'register.html'));
});

app.post('/register', (req, res) => {
  const { username, password } = req.body;
  db.run(`INSERT INTO users (username, password) VALUES (?, ?)`, [username, password], (err) => {
    if (err) {
      return res.send('用戶名已存在！');
    }
    res.redirect('/');
  });
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  db.get(`SELECT * FROM users WHERE username = ? AND password = ?`, [username, password], (err, row) => {
    if (err) {
      return res.send('錯誤！');
    }
    if (!row) {
      return res.send('用戶名或密碼錯誤！');
    }
    req.session.userId = row.id;
    console.log('User logged in successfully:', { username });
    res.redirect('/mvp_booking');
  });
});

app.get('/mvp_booking', checkAuthenticated, (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'mvp_booking.html'));
});

app.post('/submit_booking', checkAuthenticated, (req, res) => {
  const newBooking = req.body;

  const query = `INSERT INTO bookings
                (customer_id, customer_phone, reservation_date, people_count, soup1, soup2, soup3, appetizers_1, appetizers_2, main_course1, main_course2, main_course3, deluxe_1, steak_1, dessert_1, dessert_2, icecream_plus, drink_1, drink_2, drink_3)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
  const values = [
    req.session.userId,
    newBooking.customer_phone,
    newBooking.reservation_date,
    newBooking.people_count,
    newBooking.soup1,
    newBooking.soup2,
    newBooking.soup3,
    newBooking.appetizers_1,
    newBooking.appetizers_2,
    newBooking.main_course1,
    newBooking.main_course2,
    newBooking.main_course3,
    newBooking.deluxe_1,
    newBooking.steak_1,
    newBooking.dessert_1,
    newBooking.dessert_2,
    newBooking.icecream_plus,
    newBooking.drink_1,
    newBooking.drink_2,
    newBooking.drink_3
  ];

  db.run(query, values, function(err) {
    if (err) {
      console.error('Error adding booking to SQLite:', err.message);
      res.status(500).json({ success: false, message: 'Internal server error.' });
    } else {
      res.redirect('/list');
    }
  });
});

app.get('/list', checkAuthenticated, (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'mvp_list.html'));
});

app.get('/api/bookings', checkAuthenticated, (req, res) => {
  const sql = 'SELECT * FROM bookings WHERE customer_id = ?';
  db.all(sql, [req.session.userId], (err, rows) => {
    if (err) {
      res.status(400).json({ "error": err.message });
      return;
    }
    res.json({
      "message": "success",
      "data": rows
    });
  });
});

app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/');
});

// Helper function to check if user is authenticated
function checkAuthenticated(req, res, next) {
  if (req.session.userId) {
    return next();
  }
  res.redirect('/list');
}

// Server setup
app.listen(port, () => {
  console.log(`Express app listening at http://localhost:${port}`);
});

// Handle SQLite database connection closure
process.on('exit', () => {
  db.close();
  console.log('SQLite connection closed');
});
